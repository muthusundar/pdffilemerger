<?php
error_reporting(0);
if(isset($_FILES)){
    $file=array();
if(move_uploaded_file($_FILES['file1']['tmp_name'],'samplepdfs/'.$_FILES['file1']['name'])){
    $file[]='samplepdfs/'.$_FILES['file1']['name'];
}
if(move_uploaded_file($_FILES['file2']['tmp_name'],'samplepdfs/'.$_FILES['file2']['name'])){
    $file[]='samplepdfs/'.$_FILES['file2']['name'];
}
    if(move_uploaded_file($_FILES['file3']['tmp_name'],'samplepdfs/'.$_FILES['file3']['name'])){
    $file[]='samplepdfs/'.$_FILES['file3']['name'];
}
if(move_uploaded_file($_FILES['file4']['tmp_name'],'samplepdfs/'.$_FILES['file4']['name'])){
    $file[]='samplepdfs/'.$_FILES['file4']['name'];
}
    if(move_uploaded_file($_FILES['file5']['tmp_name'],'samplepdfs/'.$_FILES['file5']['name'])){
    $file[]='samplepdfs/'.$_FILES['file5']['name'];
}
if(move_uploaded_file($_FILES['file6']['tmp_name'],'samplepdfs/'.$_FILES['file6']['name'])){
    $file[]='samplepdfs/'.$_FILES['file6']['name'];
}



include 'PDFMerger.php';

$pdf = new PDFMerger;



if(count($file)==1){
   $pdf->addPDF($file[0], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf'); 
}elseif(count($file)==2){
$pdf->addPDF($file[0], 'all')
->addPDF($file[1], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf');

}elseif(count($file)==3){
$pdf->addPDF($file[0], 'all')
->addPDF($file[1], 'all')
->addPDF($file[2], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf');

}elseif(count($file)==4){
$pdf->addPDF($file[0], 'all')
->addPDF($file[1], 'all')
->addPDF($file[2], 'all')
->addPDF($file[3], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf');

}elseif(count($file)==5){
$pdf->addPDF($file[0], 'all')
->addPDF($file[1], 'all')
->addPDF($file[2], 'all')
->addPDF($file[3], 'all')
->addPDF($file[4], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf');

}elseif(count($file)==6){
$pdf->addPDF($file[0], 'all')
->addPDF($file[1], 'all')
->addPDF($file[2], 'all')
->addPDF($file[3], 'all')
->addPDF($file[4], 'all')
->addPDF($file[5], 'all')
	->merge('browser', 'samplepdfs/TEST2.pdf');

}
}
//REPLACE 'file' WITH 'browser', 'download', 'string', or 'file' for output options
	//You do not need to give a file path for browser, string, or download - just the name.
?>
	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>title</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="robots" content="index,follow" />
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>

<body>
<form name="pdfmerge" id="pdfmerge" method="post" action="" enctype="multipart/form-data">
    <p>file1:<input type="file" name="file1" id="file1"></p>
    <p>file1:<input type="file" name="file2" id="file2"></p>
    <p>file1:<input type="file" name="file3" id="file3"></p>
    <p>file1:<input type="file" name="file4" id="file4"></p>
    <p>file1:<input type="file" name="file5" id="file5"></p>
    <p>file1:<input type="file" name="file6" id="file6"></p>
    <p>file1:<input type="submit" name="submit" id="submit"></p>
</form>
</body>
</html>
 